#ifndef coeur_H_INCLUDED
#define coeur_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

//Ici on appelle les diff�rentes biblioth�ques qui corespondent aux types d'allumages du ceur de LED

#define Parametre_led;
#define 1_Led_sur2;
#define 1_Led_sur3;
#define 1_Led_sur4;
#define 1_Led_sur5;
#define 1_Led_sur6;
#define 1_Led_sur7;
#define 1_Led_sur8;
#define 1_Led_sur9;
#define 1_Led_sur10;
#define Allumage_Mode_Chenille;
#define toute_led_allumee;
#define 1_seule_au_choix;
#define Mode_chenille_inverse;
#define Fusion_chenillage_et_tout_allumer;

#endif // coeur_H_INCLUDED
