#ifndef donnee_H_INCLUDED
#define donnee_H_INCLUDED
//prototype des fonctions

int Manipulation_structure();//prototype de la fonction Manipulation_structure
void Lecture_Ficher(); //prototype de la fonction Lecture_Ficher

#endif // donnee_H_INCLUDED
