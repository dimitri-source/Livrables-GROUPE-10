#ifndef action_H_INCLUDED
#define donnee_H_INCLUDED

void Traitement_donnee();//prototype des de la fonctions traitement_donnee;
#endif // action_H_INCLUDED
