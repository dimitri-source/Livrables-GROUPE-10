#ifndef menu_H_INCLUDED
#define menu_H_INCLUDED
#include <stdio.h>
#include <stdbool.h>

void Affichage_Menu(choice);//prototype fonction affichage_menu

#endif // menu_H_INCLUDED
