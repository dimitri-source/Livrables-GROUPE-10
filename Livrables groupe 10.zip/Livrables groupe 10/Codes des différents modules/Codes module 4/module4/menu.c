#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
void Affichage_Menu(int choice)
{
int pouls[2200],x,y;
int i,j;
int  ligne[10],temps[2200];
char carac[20];
char texte[10];
int nombre_ligne[2200];
FILE* fichier= NULL;//declaration d'un fichier externe
fichier = fopen("Battements.csv","r");//ouverture de ce dernier
//affichge du menu ou des options...
    printf("\t\t******bonjour a tous,Hexart Care vous remercie pour votre presence, bienvenue pour votre text******\n");
    printf("\t\t\t\t*********Menu deroulante********\n\n");
    printf("\t\t\t\t1. Afficher les donnees dans l ordre du fichier .csv \n");
    printf("\t\t\t\t2. Afficher les donnees en ordre croissant/decroissant (selon le temps, selon le pouls)\n");
    printf("\t\t\t\t3. Rechercher et afficher les donnees pour un temps particulier\n");
    printf("\t\t\t\t4. Afficher la moyenne de pouls dans une plage de temps donnee \n");
    printf("\t\t\t\t5. Afficher le nombre de lignes de donnees actuellement en memoire \n");
    printf("\t\t\t\t6. Rechercher et afficher les max/min de pouls (avec le temps associe) \n");
    printf("\t\t\t\t7. Quitter l application \n\n");

    printf("veuillez entrer votre choix s'il vous plait  ");
    switch(getch())
    {
    case '1':
      if(fichier == NULL)//verification de l'etat du fichier battements.csv
    {
       exit(1);//fonction arret du traitement
    }
do
{
   for(j=0;j<2200;j++)
    { printf("\n\n");
    nombre_ligne[j]= fgets(ligne, 10,fichier);//lecture de la ligne du tableau
        printf("   %s",nombre_ligne[j]);//affichage des differentes lignes
        printf("\n\n");
    }//appel des fonctions manipulationS

}while(fgets(ligne, 10, fichier) != NULL);
fclose(fichier);//fermeture du fichier ouverte
        break;
    case '2':
        //affichage des options a ce niveau
        printf("\n\n");
    printf("quel type d'affichage voulez vous faire\n?");
    printf("\t\t\t\t1. Affichage des donnees en ordre croissant \n");
    printf("\t\t\t\t2. Affichage des donnees en ordre decroissant \n");
    switch(getch())
    {
    case '1':
           if(fichier == NULL)//verification de l'etat du fichier battements.csv
    {
       exit(1);//fonction arret du traitement
    }
do
{
for(j=0;j<2000;j++)
   {
fscanf(fichier,"%d;%d",&temps[j],&pouls[j]);//affectation des valeurs du fichiers dans les variables temps et pouls
printf("le temps est");//affichage d'un message
printf("%d", temps[j]);//affichage d'un message
printf("\n\n");
printf("le pouls est");//affichage d'un message
printf("%d",pouls[j]);//affichage d'un message
printf("\n\n");
   }//appel de fonction manipulation
//printf("\n\n");
  for (i=0 ;i<2200; i++)
{
    for(j=i+1 ; j<2200; j++)
    {
        if( pouls[i] >pouls[j]  )
        {
            x=pouls[i];
            pouls[i]=pouls[j];
           pouls[j]=x;
        }

    }
}
    for (i=0 ;i<2200; i++)
{
    for(j=i+1 ; j<2200; j++)
    {
        if( temps[i]> temps[j]  )
        {
            y=temps[i];
          temps[i]=temps[j];
           temps[j]=y;
        }

    }
}
printf("suivant votre choix sachez que le temps a ete ordonne et le pouls a fait de meme \n\n");

for(i=0;i<2200;i++)
{ //pouls[i] =* pouls[i];
    //temps[i]=*temps[i];
  printf("le pouls est %d ; le temps est %d ", pouls[i],temps[i]);
    printf("\n\n");//appel de la fonction traitement
}
}while(fgets(ligne, 10, fichier) != NULL);
fclose(fichier);//fermeture du fichier ouverte
        break;
    case '2':
         if(fichier == NULL)//verification de l'etat du fichier battements.csv
    {
       exit(1);//fonction arret du traitement
    }
do
{

}while(fgets(ligne, 10, fichier) != NULL);
fclose(fichier);


    break;
    default:
        printf("\n\n");
printf("soyez serieux s'il vous plait\n");//affichage d'un message
        break;
  } /* */
    break;
    case '3':
                 if(fichier == NULL)//verification de l'etat du fichier battements.csv
    {
       exit(1);//fonction arret du traitement
    }
do
{
    printf("entrer votre temps particulier\n");//affichage d'un message
    scanf("%d",&temps); //affectation de la valeur entre par l'utilisateur a la variable temps

for(i=0;i<2200;i++)
{
//    printf();
}


}while(fgets(ligne, 10, fichier) != NULL);
fclose(fichier);//fermeture du fichier ouverte

        break;
     case '4':
                  if(fichier == NULL)//verification de l'etat du fichier battements.csv
    {
       exit(1);//fonction arret du traitement
    }
do
{

}while(fgets(ligne, 10, fichier) != NULL);
fclose(fichier);//fermeture du fichier ouverte

        break;
   case '5':
         if(fichier == NULL)//verification de l'etat du fichier battements.csv
    {
       exit(1);//fonction arret du traitement
    }
do
{

}while(fgets(ligne, 10, fichier) != NULL);
fclose(fichier);//fermeture du fichier ouverte
        break;
     case '6':
                  if(fichier == NULL)//verification de l'etat du fichier battements.csv
    {
       exit(1);//fonction arret du traitement
    }
do
{

}while(fgets(ligne, 10, fichier) != NULL);
fclose(fichier);//fermeture du fichier ouverte

        break;
     case '7':
         if(fichier == NULL)//verification de l'etat du fichier battements.csv
    {
       exit(1);//fonction arret du traitement
    }
do
{

}while(fgets(ligne, 10, fichier) != NULL);
fclose(fichier);//fermeture du fichier ouverte
        break;
     case '8':
         if(fichier == NULL)//verification de l'etat du fichier battements.csv
    {
       exit(1);//fonction arret du traitement
    }
do
{

}while(fgets(ligne, 10, fichier) != NULL);
fclose(fichier);//fermeture du fichier ouverte
        break;

     default:
printf("veuillez bien regarder svp\n");//affichage d'un message
    break;

    }
}
