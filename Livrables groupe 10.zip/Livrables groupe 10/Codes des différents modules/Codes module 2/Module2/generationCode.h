 #ifndef generationCode_H_INCLUDED
#define generationCode_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

//Ici on d�clare les fonctions qu'on va appeler dans le main.c

        int Parametre_led( param, choix);
#endif//generationCode_code_INCLUDED
