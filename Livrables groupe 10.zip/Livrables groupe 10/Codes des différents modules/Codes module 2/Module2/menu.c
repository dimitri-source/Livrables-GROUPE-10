#include <stdio.h>
#include <stdlib.h>
#include "generationCode.h"
void Affichage_Menu(choice)
{
    //  voici le menu qui va s'afficher

    printf("\t\t******bonjour a tous, Hexart Care vous remercie pour votre presence, bienvenue pour votre test******\n");
    printf("\t\t\t\t*********Menu deroulante********\n\n");
    printf("\t\t\t\t1. Toutes les LEDs allumees en meme temps au rythme des battements de c�ur\n");
    printf("\t\t\t\t2. 1 LED sur 2 allumee \n");
    printf("\t\t\t\t3. 1 LED sur 3 allumee\n");
    printf("\t\t\t\t4. 1 LED sur 4 allumee\n");
    printf("\t\t\t\t5. 1 LED sur 5 allumee\n");
    printf("\t\t\t\t6. 1 LED sur 6 allumee\n");
    printf("\t\t\t\t7. 1 LED sur 7 allumee\n");
    printf("\t\t\t\t8. 1 LED sur 8 allumee\n");
    printf("\t\t\t\t9. 1 LED sur 9 allumee\n");
    printf("\t\t\t\t10. 1 LED sur 10 allumee\n");
    printf("\t\t\t\t11. 1 seule LED allumee au choix\n");
    printf("\t\t\t\t12. Allumer le coeur en mode  chenille  \n");
    //printf("\t\t\t\t13. Toute autre idee peut etre proposee \n\n");
     printf("\t\t\t\t13. Allumer le coeur en mode chenille inverse\n");
     printf("\t\t\t\t14. affichage sous forme de fusion de chenillage et allumage global des led\n\n");

}
