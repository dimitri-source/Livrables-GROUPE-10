#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "generationCode.h"
//#include "coeur.h"
//#include "param.h"

int main()
{// char color;
    int choice,conti;
int choix;
   FILE* param = NULL;
 param = fopen("param.h","r+");
 //FILE* fopen(const char* nomDuFichier, const char* modeOuverture);
    system("color af");
//system(" start 1_Led_sur3\\1_Led_sur3.ino");
   // Affichage_Menu(choice);
   if(param != NULL)
    {
        do
        {
                Affichage_Menu(choice);
    Parametre_led( param, choix);
    printf("voulez vous continuer\n");
    printf("1. pour continuer\n");
    printf("0. pour quitter\n");
scanf("%d",&conti);
if(conti==0)
{
    printf("aurevoir et merci pour votre participation\n\n");
}
else
{
    printf("\n\n");
}
        }while(conti);
//choix = param;

    }else
    {
        printf("il ya erreur");
    }

    return 0;
}
