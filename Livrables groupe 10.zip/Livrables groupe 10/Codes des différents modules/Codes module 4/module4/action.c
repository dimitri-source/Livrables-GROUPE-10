#include "action.h"
#include <stdio.h>
#include <stdlib.h>

void Traitement_donnee()//declaration de la fonction traitement de donnee permettant de traiter les donnees
{




    return 0;
}
