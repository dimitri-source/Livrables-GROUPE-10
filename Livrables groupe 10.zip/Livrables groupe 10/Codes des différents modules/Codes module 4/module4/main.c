#include <stdio.h>
#include <stdlib.h>
#include "donnees.h"
#include "action.h"
#include "menu.h"

//*******declaration d'une structure info qui gere les informations
typedef struct info info;
struct info
{
    int temps[2200];
    int pouls[2200];
};

int main()
{ int choice;//declaration d'une variable choix permettant de stocker votre choix
system("color af");//definition de la couleur d'arriere plan et du texte
printf("Hello world!\n");//affichage hello word

Affichage_Menu(choice);//appel de la fontion Affichage_Menu
FILE* fichier= NULL;//declaration d'un fichier externe
fichier = fopen("battements.csv","r");//ouverture d'un fichier battements.csv

return 0;
}
