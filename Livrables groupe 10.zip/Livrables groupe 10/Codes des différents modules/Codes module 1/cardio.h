
void calculpouls();
