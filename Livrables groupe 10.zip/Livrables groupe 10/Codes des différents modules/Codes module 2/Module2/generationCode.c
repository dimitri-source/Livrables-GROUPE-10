#include "generationCode.h"
#include <stdio.h>
#include <stdlib.h>

int Parametre_led( param,  choix)
{ int conti;
printf("choisir la maniere donc vous voulez que la Led sallume\n\n");
   scanf("%d", &choix);
    switch(choix)
    {
    case 1:
printf("vous avez choisi allumage de toute vos led ,tres bon choix\n");
printf("veuliez televerser le programme svp\n");
        system("start toute_led_allumee\\toute_led_allumee.ino");
fputs("#ifndef param_H_INCLUDED\n",param); //ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define toute_led_allumee\n",param);
fputs("\n\n\n",param);


fputs("#endif ",param);
fclose(param);
printf("\n\n");

    break;
    case 2:
printf("vous avez choisi le mode 1_led sur 2,c'est cool,amusez vous bien surtout\n");
printf("veuliez televerser le programme svp\n");
system("start 1_led_sur2_\\1_led_sur2_.ino");
fputs("#ifndef param_H_INCLUDED\n",param);//ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define 1_led_sur2",param);
fputs("\n\n\n",param);
fputs("#endif ",param);
fclose(param);
printf("\n\n");

    break;
  case 3:
    printf("vous avez choisi le mode 1 led sur 3,ca marche prenez surtout du plaisir\n");
      printf("veuliez televerser le programme svp\n");
        system("start 1_led_sur3\\1_led_sur3.ino");
      fputs("#ifndef param_H_INCLUDED\n",param); //ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define 1_led_sur3",param);
fputs("\n\n\n",param);
fputs("#endif" ,param);
fclose(param);
printf("\n\n");

    break;
  case 4:
      printf("vous avez choisir le mode 1 led sur 4,ok,passer donc un bon moment avec ce mode\n");
       printf("veuliez televerser le programme svp\n");
        system("start 1_led_sur4\\1_led_sur4.ino");
    fputs("#ifndef param_H_INCLUDED\n",param); //ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define 1_led_sur4",param);
fputs("\n\n\n",param);
fputs("#endif" ,param);
fclose(param);
printf("\n\n");


    break;
  case 5:
    printf("vous avez choisir le mode 1 led sur 5,c'est un top choix\n");
       printf("veuliez televerser le programme svp\n");
        system("start 1_led_sur5\\1_led_sur5.ino");
            fputs("#ifndef param_H_INCLUDED\n",param); //ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define 1_led_sur5",param);
fputs("\n\n\n",param);
fputs("#endif ",param);
fclose(param);
printf("\n\n");

    break;
  case 6:
      printf("vous avez choisir le mode 1 led sur 6, je vous souhaite de passer un bon temps avec ce mode\n");
       printf("veuliez televerser le programme svp\n");
        system("start 1_led_sur6\\1_led_sur6.ino");
           fputs("#ifndef param_H_INCLUDED\n",param); //ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define 1_led_sur6",param);
fputs("\n\n\n",param);
fputs("#endif" ,param);
fclose(param);
printf("\n\n");

    break;
  case 7:
      printf("vous avez choisir le mode 1 led sur 7,donc a vous de jouer mais avant\n");
       printf("veuliez televerser le programme svp\n");
        system("start 1_led_sur7\\1_led_sur7.ino");
            fputs("#ifndef param_H_INCLUDED\n",param); //ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define 1_led_sur7",param);
fputs("\n\n\n",param);
fputs("#endif" ,param);
fclose(param);
printf("\n\n");

    break;
  case 8:
      printf("vous avez selectionner le mode 1 led sur 8,c'est un choix fabuleux,je vous dirais bien a vous de jouer mais vous devez d'arbord\n");
       printf("veuliez televerser le programme svp\n");
        system("start 1_led_sur8\\1_led_sur8.ino");
      fputs("#ifndef param_H_INCLUDED\n",param); //ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define 1_led_sur8",param);
fputs("\n\n\n",param);
fputs("#endif ",param);
fclose(param);
printf("\n\n");

    break;
  case 9:
      printf("vous avez choisir le mode d'allumage 1 led sur 9,ca passe,je vous dirais bien amusez-vous bien mais vous devez d'arbord\n");
printf("veuliez televerser le programme svp\n");
        system("start 1_led_sur9\\1_led_sur9.ino");
   fputs("#ifndef param_H_INCLUDED\n",param); //ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define 1_led_sur9",param);
fputs("\n\n\n",param);
fputs("#endif" ,param);
fclose(param);
printf("\n\n");

    break;
  case 10:
      printf("vous avez opter pour le mode 1 led sur 10,pas tres optimal mais sa reste votre choix,je vous dirais bien regarlez-vous bien mais vous devez d'arbord\n");
printf("veuliez televerser le programme svp\n");
        system("start 1_led_sur10\\1_led_sur10.ino");
    fputs("#ifndef param_H_INCLUDED\n",param); //ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define 1_led_sur10",param);
fputs("\n\n\n",param);
fputs("#endif ",param);
fclose(param);
printf("\n\n");

    break;
  case 11:
      printf("vous avez choisir le mode 1 led au choix qui est un tres bon choix,pour que vore joie soit optimale svp penser a\n");
     printf("veuliez televerser le programme svp\n");
        system("start  1_seule_au_choix\\1_seule_au_choix.ino");
      fputs("#ifndef param_H_INCLUDED\n",param); //ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define 1_seule_au_choix",param);
fputs("\n\n\n",param);
fputs("#endif ",param);
fclose(param);

printf("\n\n");
    break;
  case 12:
      printf("vous avez opter pour le mode chenillage qui me parait un tres bon choix de votre part mais pour pouvoir apprecier la splendeur de ce code vous devez\n");
    printf("veuliez televerser le programme svp\n");
        system("start Allumage_Mode_Chenille\\Allumage_Mode_Chenille.ino");
      fputs("#ifndef param_H_INCLUDED\n",param); //ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define Allumage_Mode_Chenille",param);
fputs("\n\n\n",param);
fputs("#endif" ,param);
fclose(param);
printf("\n\n");

    break;
  case 13:

    printf("vous avez opter pour le mode chenillage qui me parait un tres bon choix de votre part mais pour pouvoir apprecier la splendeur de ce code vous devez\n");
   printf("veuliez televerser le programme svp\n");
    system("start Mode_chenille_inverse\\Mode_chenille_inverse.ino");
fputs("#ifndef param_H_INCLUDED\n",param); //ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define Mode_chenille_inverse",param);
fputs("\n\n\n",param);
fputs("#endif ",param);
fclose(param);
printf("\n\n");

    break;

      case 14:

    printf("vous avez opter pour le mode chenillage qui me parait un tres bon choix de votre part mais pour pouvoir apprecier la splendeur de ce code vous devez\n");
   printf("veuliez televerser le programme svp\n");
    system("start Fusion_chenillage_et_tout_allumer\\Fusion_chenillage_et_tout_allumer.ino");
fputs("#ifndef param_H_INCLUDED\n",param); //ecrit une ligne
fputs("#define param_H_INCLUDED\n",param);
fputs("#include <stdio.h>\n",param);
fputs("#include <stdbool.h>\n",param);
fputs("#define Fusion_chenillage_et_tout_allumer",param);
fputs("\n\n\n",param);
fputs("#endif ",param);
fclose(param);
printf("\n\n");

    break;
  default:
    printf("desole Mr mais vous vous ee tromper veulliez bien lire les informations affichees\n");
    }

}
