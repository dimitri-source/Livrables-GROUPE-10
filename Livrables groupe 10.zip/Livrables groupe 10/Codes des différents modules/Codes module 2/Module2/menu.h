#ifndef menu_H_INCLUDED
#define menu_H_INCLUDED
#include <stdio.h>
#include <stdbool.h>

void Affichage_Menu(choice);

#endif // menu_H_INCLUDED
