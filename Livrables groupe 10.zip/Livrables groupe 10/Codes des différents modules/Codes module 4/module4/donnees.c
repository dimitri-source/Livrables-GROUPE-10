#include "donnees.h"
#include <stdio.h>
#include <stdlib.h>

int Manipulation_structure()//declaration d'une fonction n�cessaires pour la manipulation de la structure de donn�es
{

return 0;
}
void Lecture_Ficher()//declaration d'une fonction de lecture de fichier;
{

}
