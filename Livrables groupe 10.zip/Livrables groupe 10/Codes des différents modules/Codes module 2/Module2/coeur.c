
// Inclusion des librairies
#include <Arduino.h>
#include "param.h"

// D�finition des pins des LEDs
int ledPins[10] = {9, 7, 2, 3, 5, 4, 6, 8, 11, 10};

// D�finit les LEDs en tant que sorties et les RAZ
void defineLeds() {
  for(int i = 0; i < (sizeof(ledPins) / sizeof(ledPins[0])); i++){
    pinMode(ledPins[i], OUTPUT);
    digitalWrite(ledPins[i], LOW);
  }
}

// Allume les LEDs selon le mode choisi en fonction de la cardiofr�quence
void allumageLeds() {
  switch (choixParam) {
    case 1:
      // Allume toutes les LEDs en m�me temps
      for(int i = 0; i < (sizeof(ledPins) / sizeof(ledPins[0])); i++){
        digitalWrite(ledPins[i], HIGH);
      }
      delay(100);
      for(int i = 0; i < (sizeof(ledPins) / sizeof(ledPins[0])); i++){
        digitalWrite(ledPins[i], LOW);
      }
      delay(100);
      break;
    case 2:
      // Allume 1/2 LEDs
      digitalWrite(ledPins[0], HIGH);
      digitalWrite(ledPins[2], HIGH);
      digitalWrite(ledPins[4], HIGH);
      digitalWrite(ledPins[6], HIGH);
      digitalWrite(ledPins[8], HIGH);
      digitalWrite(ledPins[1], LOW);
      digitalWrite(ledPins[3], LOW);
      digitalWrite(ledPins[5], LOW);
      digitalWrite(ledPins[7], LOW);
      digitalWrite(ledPins[9], LOW);
      delay(100);
      digitalWrite(ledPins[0],  LOW);
      digitalWrite(ledPins[2],  LOW);
      digitalWrite(ledPins[4],  LOW);
      digitalWrite(ledPins[6],  LOW);
      digitalWrite(ledPins[8],  LOW);
      digitalWrite(ledPins[1],  HIGH);
      digitalWrite(ledPins[3],  HIGH);
      digitalWrite(ledPins[5],  HIGH);
      digitalWrite(ledPins[7],  HIGH);
      digitalWrite(ledPins[9],  HIGH);
      delay(100);
      digitalWrite(ledPins[1],  LOW);
      digitalWrite(ledPins[3],  LOW);
      digitalWrite(ledPins[5],  LOW);
      digitalWrite(ledPins[7],  LOW);
      digitalWrite(ledPins[9],  LOW);
      break;
    case 3:
      // Allume 1/3 LEDs
      digitalWrite(ledPins[0], HIGH);
      digitalWrite(ledPins[3], HIGH);
      digitalWrite(ledPins[6], HIGH);
      digitalWrite(ledPins[9], HIGH);
      digitalWrite(ledPins[1], LOW);
      digitalWrite(ledPins[4], LOW);
      digitalWrite(ledPins[7], LOW);
      digitalWrite(ledPins[2], LOW);
      digitalWrite(ledPins[5], LOW);
      digitalWrite(ledPins[8], LOW);
      delay(66);
      digitalWrite(ledPins[0], LOW);
      digitalWrite(ledPins[3], LOW);
      digitalWrite(ledPins[6], LOW);
      digitalWrite(ledPins[9], LOW);
      digitalWrite(ledPins[1], HIGH);
      digitalWrite(ledPins[4], HIGH);
      digitalWrite(ledPins[7], HIGH);
      digitalWrite(ledPins[2], LOW);
      digitalWrite(ledPins[5], LOW);
      digitalWrite(ledPins[8], LOW);
      delay(66);
      digitalWrite(ledPins[0], LOW);
      digitalWrite(ledPins[3], LOW);
      digitalWrite(ledPins[6], LOW);
      digitalWrite(ledPins[9], LOW);
      digitalWrite(ledPins[1], LOW);
      digitalWrite(ledPins[4], LOW);
      digitalWrite(ledPins[7], LOW);
      digitalWrite(ledPins[2], HIGH);
      digitalWrite(ledPins[5], HIGH);
      digitalWrite(ledPins[8], HIGH);
      delay(66);
      digitalWrite(ledPins[2], LOW);
      digitalWrite(ledPins[5], LOW);
      digitalWrite(ledPins[8], LOW);
      break;
    case 4:
      // Allume les LEDs en mode chenille
      for(int i = 0; i < (sizeof(ledPins) / sizeof(ledPins[0])); i++){
        digitalWrite(ledPins[i], HIGH);
        delay(30);
        digitalWrite(ledPins[i], LOW);
        delay(30);
      }
      break;
    case 5:
      // Allume une LED au choix
      digitalWrite(pinLedy - 2, HIGH);
      delay(100);
      digitalWrite(pinLedy - 2, LOW);
      delay(100);
      break;
    case 6:
      // Mode personnalis�: Yo-Yo
      for(int i = 0; i < (sizeof(ledPins) / sizeof(ledPins[0])); i++){
        digitalWrite(ledPins[i], HIGH);
        digitalWrite(ledPins[9 - i], HIGH);
        delay(30);
        digitalWrite(ledPins[i], LOW);
        digitalWrite(ledPins[9 - i], LOW);
        delay(30);
      }
  }
}
